const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{spawnSync}=require('node:child_process');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root=path.resolve(__dirname,'..'),data=fs.mkdtempSync(path.join(os.tmpdir(),'planner-ui-'));
const env={...process.env,WATTPIT_TEST:'1',WATTPIT_TEST_DATA:data};
function control(args){const p=spawnSync('sh',[path.join(root,'control.sh'),...args],{env,encoding:'utf8'});return {code:p.status,out:p.stdout,err:p.stderr};}
async function attach(page){
 await page.exposeFunction('plannerHost',cmd=>{
  const tail=cmd.slice(cmd.indexOf("/control.sh'")+12),args=[...tail.matchAll(/'([^']*)'/g)].map(x=>x[1]);
  assert.ok(['read','save','open'].includes(args[0]),cmd);return control(args);
 });
 await page.addInitScript(()=>{window.ksu={moduleInfo:()=>'{"moduleDir":"/data/adb/modules/wattpit_reboot"}',exec:(cmd,opts,callback)=>window.plannerHost(cmd).then(r=>window[callback](r.code,r.out,r.err))};});
 await page.goto('file://'+path.join(root,'webroot/index.html'));
 await page.waitForFunction(()=>!document.getElementById('fields').disabled);
}
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.WATTPIT_CHROMIUM||'/workspace/scratch/d08483c1a313/runtime161/headless/chrome-headless-shell-linux64/chrome-headless-shell',headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:360,height:800},colorScheme:'dark'});
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 try{
  await attach(page);
  assert.equal(await page.locator('#enabled').isChecked(),false);assert.equal(await page.locator('#delay').inputValue(),'1');assert.equal(await page.locator('#delayUnit').inputValue(),'60');
  await page.locator('#delayUnit').selectOption('1');assert.equal(await page.locator('#delay').inputValue(),'60');
  await page.locator('#delay').fill('300');await page.locator('#delayUnit').selectOption('60');assert.equal(await page.locator('#delay').inputValue(),'5');
  await page.locator('#enabled').check();await page.locator('.distribute summary').click();await page.locator('#count').fill('100');await page.locator('#distribute').click();assert.equal(await page.locator('.time-item').count(),100);
  await page.locator('#save').click();await page.waitForFunction(()=>document.getElementById('message').textContent.startsWith('Gespeichert.'));
  let c=JSON.parse(control(['read']).out).config;assert.equal(c.times.split(',').length,100);assert.equal(c.delay_seconds,300);assert.equal(c.enabled,1);
  await page.reload();await page.waitForFunction(()=>!document.getElementById('fields').disabled);assert.equal(await page.locator('.time-item').count(),100);assert.equal(await page.locator('#delay').inputValue(),'5');
  await page.locator('#delay').fill('-1');await page.locator('#save').click();await page.waitForFunction(()=>document.getElementById('message').classList.contains('error'));assert.equal(JSON.parse(control(['read']).out).config.delay_seconds,300);
  await page.locator('#delay').fill('0');await page.locator('#enabled').uncheck();await page.locator('#save').click();await page.waitForFunction(()=>document.getElementById('message').textContent.startsWith('Gespeichert.'));c=JSON.parse(control(['read']).out).config;assert.equal(c.delay_seconds,0);assert.equal(c.enabled,0);
  await page.locator('#delayUnit').selectOption('1');assert.equal(await page.locator('#delay').inputValue(),'0');
  await page.locator('#enabled').check();await page.locator('#mode').selectOption('interval');await page.locator('#interval').fill('15');await page.locator('#save').click();await page.waitForFunction(()=>document.getElementById('message').textContent.startsWith('Gespeichert.'));assert.equal(JSON.parse(control(['read']).out).config.interval_minutes,15);
  await page.locator('#mode').selectOption('times');
  for(const width of [320,360,720])for(const scale of [1,1.5])for(const theme of ['dark','light']){
   await page.setViewportSize({width,height:850});await page.emulateMedia({colorScheme:theme});await page.evaluate(s=>{document.documentElement.style.fontSize=16*s+'px'},scale);
   const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1);assert.equal(overflow,false,`overflow ${width} ${scale} ${theme}`);
  }
  await page.setViewportSize({width:360,height:900});await page.emulateMedia({colorScheme:'dark'});await page.evaluate(()=>{document.documentElement.style.fontSize='16px'});
  fs.mkdirSync(path.join(root,'../wattpit-planner-tests'),{recursive:true});await page.screenshot({path:path.join(root,'../wattpit-planner-tests/planner-ui.png'),fullPage:true});
  assert.deepEqual(errors,[]);
  const denied=await browser.newPage();await denied.goto('file://'+path.join(root,'webroot/index.html'));await denied.waitForFunction(()=>!document.getElementById('message').hidden);assert.equal(await denied.evaluate(()=>document.getElementById('fields').disabled),true);
  console.log('PASS real settings backend through WebUI bridge: 100 times, five-minute delay, unit conversion, reload, zero, off, invalid input, interval, 12 responsive/theme/font layouts, missing-root handling');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1)});
