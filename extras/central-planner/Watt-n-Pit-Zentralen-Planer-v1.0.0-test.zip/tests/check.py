#!/usr/bin/env python3
"""Host-only checks. No Android reboot or app start can execute on this host."""
import base64,json,os,pathlib,subprocess,tempfile
root=pathlib.Path(__file__).resolve().parents[1]
data=pathlib.Path(tempfile.mkdtemp(prefix='wattpit-planner-'))
env={**os.environ,'WATTPIT_TEST':'1','WATTPIT_TEST_DATA':str(data)}
checks=0
def run(*args):
 return subprocess.run(['sh',str(root/'control.sh'),*args],env=env,capture_output=True,text=True)
def check(ok,name):
 global checks
 assert ok,name
 checks+=1;print('PASS',name)
def read():
 p=run('read');assert p.returncode==0,p.stderr
 return json.loads(p.stdout)
def payload(c):
 return 'version=1\n'+''.join(str(k)+'='+str(c[k])+'\n' for k in ('enabled','mode','times','interval_minutes','autostart','delay_seconds'))
def save(c,rev=None):
 return run('save',base64.b64encode(payload(c).encode()).decode(),rev or read()['revision'])
s=read();c=s['config'];check(c['enabled']==0 and c['autostart']==1 and c['delay_seconds']==60,'fresh install has no scheduled reboot and a 60-second autostart delay')
times=','.join(f'{i*1440//100//60:02d}:{i*1440//100%60:02d}' for i in range(100))
c={**c,'enabled':1,'times':times,'delay_seconds':300}
old=s['revision'];p=save(c);check(p.returncode==0,p.stderr or '100 daily times and five-minute launch delay persist')
check(read()['config']==c,'fresh process reads exactly the saved 100-times configuration')
p=save({**c,'enabled':0},old);check(p.returncode!=0 and read()['config']==c,'stale UI cannot overwrite newer settings')
before=read()
for change,name in [({'delay_seconds':-1},'negative delay'),({'times':'24:00'},'invalid hour'),({'times':'07:00,07:00'},'duplicate time'),({'times':'07:00,',},'empty time item'),({'times':'07:00\nmode=interval'},'injected setting'),({'delay_seconds':'$(touch '+str(data/'injected')+')'},'shell command injection'),({'interval_minutes':1},'reboot interval below two minutes'),({'mode':'interval','interval_minutes':2},'reboot interval shorter than launch delay')]:
 p=save({**c,**change});check(p.returncode!=0 and read()['config']==before['config'],'reject '+name+' without changing saved configuration')
check(not (data/'injected').exists(),'configuration was never evaluated as shell code')
(data/'save.lock').mkdir();(data/'save.lock/owner').write_text('99999999')
p=save({**c,'enabled':0,'times':''});check(p.returncode==0,'abandoned save lock recovers after interrupted process')
c={**c,'enabled':0,'times':'','delay_seconds':0};p=save(c);check(p.returncode==0 and read()['config']['delay_seconds']==0,'zero delay and disabled reboot plan are valid')
def due(enabled,mode,times,interval,now,stamp,first,ready,anchor,fired=''):
 script='. "$MODDIR/common.sh"\nENABLED="$1";MODE="$2";TIMES="$3";INTERVAL="$4";due "$5" "$6" "$7" "$8" "$9" "${10}"'
 return subprocess.run(['sh','-c',script,'proof',str(enabled),mode,times,str(interval),str(now),stamp,first,str(ready),str(anchor),fired],env={**env,'MODDIR':str(root)},capture_output=True,text=True)
check(due(1,'times','07:00,19:00',720,1000,'202610310700','202610310600',100,100).stdout.strip()=='time:202610310700','scheduled local minute fires')
check(due(0,'times','07:00',720,1000,'202610310700','202610310600',100,100).returncode!=0,'master switch disables scheduled reboots')
check(due(1,'times','07:00',720,1000,'202610310700','202610310700',100,100).returncode!=0,'startup minute is not replayed')
check(due(1,'times','07:00',720,150,'202610310700','202610310600',100,100).returncode!=0,'two-minute startup guard prevents immediate reboot')
check(due(1,'times','07:00',720,1000,'202610310700','202610310600',100,100,'202610310700').returncode!=0,'acknowledged wall-clock slot is not repeated')
check(due(1,'times','07:00',720,1000,'202610310701','202610310600',100,100).returncode!=0,'missed daily slot is not caught up')
check(due(1,'interval','',5,399,'202610310700','202610310600',100,100).returncode!=0,'interval does not fire early')
check(due(1,'interval','',5,400,'202610310700','202610310600',100,100).stdout.strip()=='interval:100','interval fires at elapsed deadline')
def launch(now,ready,delay,enabled=1,launched=0,last=0):
 return subprocess.run(['sh','-c','. "$MODDIR/common.sh";launch_due "$@"','proof',*map(str,(now,ready,delay,enabled,launched,last))],env={**env,'MODDIR':str(root)},capture_output=True,text=True).returncode==0
check(not launch(399,100,300) and launch(400,100,300),'five-minute app delay expires exactly after Android readiness')
check(launch(20,20,0),'zero delay launches immediately, including a fast system boot')
check(not launch(500,100,0,enabled=0),'autostart can be independently disabled')
check(not launch(500,100,0,launched=400),'an already launched app is not repeatedly brought to the front')
check(not launch(500,100,0,last=490) and launch(520,100,0,last=490),'failed app launch is retried after 30 seconds, without a tight loop')
check(not launch(250,100,300) and launch(250,100,60),'changing a pending delay applies to the existing boot readiness time')
check(run('open').returncode!=0,'host cannot execute Android app-start command')
p=subprocess.run(['sh',str(root/'daemon.sh')],env=env,capture_output=True,text=True);check(p.returncode!=0,'host cannot run reboot daemon')
print('Checks:',checks)
