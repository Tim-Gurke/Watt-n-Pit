#!/system/bin/sh
MODDIR=${0%/*}
nohup /system/bin/sh "$MODDIR/daemon.sh" >/dev/null 2>&1 < /dev/null &
