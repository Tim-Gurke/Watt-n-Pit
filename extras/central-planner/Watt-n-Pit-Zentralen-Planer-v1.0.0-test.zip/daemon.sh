#!/system/bin/sh
if [ -x /data/adb/magisk/busybox ] && [ "${WATTPIT_BUSYBOX:-}" != 1 ]; then
  export WATTPIT_BUSYBOX=1 ASH_STANDALONE=1
  exec /data/adb/magisk/busybox ash "$0" "$@"
fi
MODDIR=${0%/*}
. "$MODDIR/common.sh"
android_only || exit 1
init_data || exit 1
worker_running && exit 0
if ! mkdir "$DATA/worker.lock" 2>/dev/null; then
  # Only discard a stale lock when its recorded process is gone.
  worker_running && exit 0
  sleep 1
  worker_running && exit 0
  rmdir "$DATA/worker.lock" 2>/dev/null || exit 1
  mkdir "$DATA/worker.lock" 2>/dev/null || exit 1
fi
printf '%s\n' "$$" > "$DATA/daemon.pid"
trap 'rm -f "$DATA/daemon.pid"; rmdir "$DATA/worker.lock" 2>/dev/null' EXIT
trap 'exit 0' TERM INT
BOOT=$(boot_id)
if [ "$(cat "$DATA/boot" 2>/dev/null)" != "$BOOT" ]; then
  state_put boot "$BOOT"
  rm -f "$DATA/ready" "$DATA/launched" "$DATA/anchor"
fi
FIRST_MINUTE=$(local_date +%Y%m%d%H%M)
LAST_REV=''; LAST_TRY=0
while [ ! -f "$MODDIR/disable" ] && [ ! -f "$MODDIR/remove" ]; do
  if [ "$(/system/bin/getprop sys.boot_completed)" != 1 ]; then sleep 3; continue; fi
  NOW=$(uptime_seconds)
  READY=$(read_number ready)
  if [ "$READY" = 0 ]; then
    READY=$NOW
    state_put ready "$READY"
    state_put anchor "$READY"
    FIRST_MINUTE=$(local_date +%Y%m%d%H%M)
    event 'Android ist bereit. Startverzögerung läuft ab jetzt.'
  fi
  REV=$(revision)
  if [ "$LAST_REV" != "$REV" ]; then
    if ! load_config; then sleep 10; continue; fi
    # Changing display delay or autostart must not silently move a reboot deadline.
    NEW_SCHEDULE="$ENABLED|$MODE|$TIMES|$INTERVAL"
    if [ -n "$LAST_REV" ] && [ "$NEW_SCHEDULE" != "$SCHEDULE" ]; then
      state_put anchor "$NOW"
      FIRST_MINUTE=$(local_date +%Y%m%d%H%M)
    fi
    SCHEDULE=$NEW_SCHEDULE; LAST_REV=$CONFIG_REV
  fi
  LAUNCHED=$(read_number launched)
  if launch_due "$NOW" "$READY" "$DELAY" "$AUTOSTART" "$LAUNCHED" "$LAST_TRY"; then
    LAST_TRY=$NOW
    if open_app; then state_put launched "$NOW"; fi
  fi
  STAMP=$(local_date +%Y%m%d%H%M)
  FIRED=$(grep -F -x "$STAMP" "$DATA/fired" 2>/dev/null)
  ANCHOR=$(read_number anchor)
  if TRIGGER=$(due "$NOW" "$STAMP" "$FIRST_MINUTE" "$READY" "$ANCHOR" "$FIRED"); then
    # Commit the slot before requesting Android's orderly reboot. A failure must
    # never lead to a rapid retry or repeated execution after a clock change.
    case "$TRIGGER" in time:*) printf '%s\n' "$STAMP" >> "$DATA/fired";; esac
    state_put anchor "$NOW"
    event 'Geplanter Handy-Neustart wird angefordert.'
    if ! /system/bin/reboot; then event 'Android hat den Neustart abgelehnt.'; fi
    sleep 60
  else
    sleep 10
  fi
done
