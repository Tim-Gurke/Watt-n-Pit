#!/system/bin/sh
if [ -x /data/adb/magisk/busybox ] && [ "${WATTPIT_BUSYBOX:-}" != 1 ]; then
  export WATTPIT_BUSYBOX=1 ASH_STANDALONE=1
  exec /data/adb/magisk/busybox ash "$0" "$@"
fi
MODDIR=${0%/*}
. "$MODDIR/common.sh"
if [ ! -x /system/bin/getprop ] && [ "${WATTPIT_TEST:-}" != 1 ]; then
  echo 'Nur auf Android mit Magisk verwenden.' >&2; exit 1
fi
init_data || exit 1
read_state() {
  load_config || return 1
  local running=false disabled=false same=false ready=0 launched=0 anchor=0 log64 rev current boot
  worker_running && running=true
  { [ -f "$MODDIR/disable" ] || [ -f "$MODDIR/remove" ]; } && disabled=true
  current=$(boot_id); boot=$(cat "$DATA/boot" 2>/dev/null)
  if [ "$current" = "$boot" ]; then
    same=true; ready=$(read_number ready); launched=$(read_number launched); anchor=$(read_number anchor)
  fi
  log64=''
  [ ! -f "$DATA/log" ] || log64=$(base64 < "$DATA/log" | tr -d '\n')
  rev=$CONFIG_REV
  printf '{"revision":"%s","config":{"enabled":%s,"mode":"%s","times":"%s","interval_minutes":%s,"autostart":%s,"delay_seconds":%s},' "$rev" "$ENABLED" "$MODE" "$TIMES" "$INTERVAL" "$AUTOSTART" "$DELAY"
  printf '"state":{"running":%s,"disabled":%s,"thisBoot":%s,"ready":%s,"launched":%s,"anchor":%s,"uptime":%s,"logBase64":"%s"}}\n' "$running" "$disabled" "$same" "$ready" "$launched" "$anchor" "$(uptime_seconds)" "$log64"
}
case "${1:-}" in
  read) read_state;;
  save)
    [ "$#" = 3 ] && [ "${#2}" -le 22000 ] || { echo 'Ungültige Anfrage.' >&2; exit 1; }
    case "$2" in *[!A-Za-z0-9+/=]*) echo 'Ungültige Einstellungen.' >&2; exit 1;; esac
    case "$3" in ''|*[!0-9-]*) echo 'Ungültiger Stand.' >&2; exit 1;; esac
    save_lock || { echo 'Einstellungen werden gerade gespeichert. Erneut versuchen.' >&2; exit 1; }
    trap 'rm -f "$DATA/input.$$" "$DATA/new.$$" "$DATA/save.lock/owner"; rmdir "$DATA/save.lock" 2>/dev/null' EXIT
    [ "$3" = "$(revision)" ] || { echo 'Die Einstellungen wurden inzwischen geändert. Bitte neu laden.' >&2; exit 1; }
    printf '%s' "$2" | base64 -d > "$DATA/input.$$" || exit 1
    [ "$(wc -c < "$DATA/input.$$")" -le 16384 ] || { echo 'Einstellungen zu groß.' >&2; exit 1; }
    awk -f "$MODDIR/validate.awk" "$DATA/input.$$" > "$DATA/new.$$" || exit 1
    chmod 0600 "$DATA/new.$$"
    mv "$DATA/new.$$" "$DATA/config" || exit 1
    event 'Einstellungen gespeichert.'
    start_worker || exit 1
    read_state;;
  open) open_app && read_state;;
  *) echo 'Unbekannte Aktion.' >&2; exit 1;;
esac
