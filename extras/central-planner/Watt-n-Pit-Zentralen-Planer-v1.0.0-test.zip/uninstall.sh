#!/system/bin/sh
MODDIR=${0%/*}
. "$MODDIR/common.sh"
if worker_running; then kill "$(cat "$DATA/daemon.pid")" 2>/dev/null; fi
rm -rf "$DATA"
