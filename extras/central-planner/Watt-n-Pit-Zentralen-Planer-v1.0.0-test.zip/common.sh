#!/system/bin/sh
# All configuration is parsed as data. Nothing from a settings file is evaluated.
MODDIR=${MODDIR:-${0%/*}}
DATA=/data/adb/wattpit_reboot
if [ ! -x /system/bin/getprop ] && [ "${WATTPIT_TEST:-}" = 1 ]; then
  DATA=${WATTPIT_TEST_DATA:?Test directory required}
fi
umask 077

init_data() {
  mkdir -p "$DATA" || return 1
  chmod 0700 "$DATA"
  if [ ! -f "$DATA/config" ]; then
    local tmp="$DATA/default.$$"
    defaults > "$tmp" || return 1
    # A concurrent reader must not replace an existing saved configuration.
    ln "$tmp" "$DATA/config" 2>/dev/null
    rm -f "$tmp"
  fi
}
defaults() {
  printf '%s\n' 'version=1' 'enabled=0' 'mode=times' 'times=07:00,19:00' 'interval_minutes=720' 'autostart=1' 'delay_seconds=60'
}
revision() { cksum "$DATA/config" | awk '{print $1 "-" $2}'; }
value() { awk -F= -v key="$2" '$1==key {print substr($0,index($0,"=")+1);exit}' "$1" 2>/dev/null; }
load_config() {
  local normalized
  normalized=$(awk -f "$MODDIR/validate.awk" "$DATA/config") || return 1
  CONFIG_REV=$(printf '%s\n' "$normalized" | cksum | awk '{print $1 "-" $2}')
  ENABLED=$(printf '%s\n' "$normalized" | awk -F= '$1=="enabled"{print $2}')
  MODE=$(printf '%s\n' "$normalized" | awk -F= '$1=="mode"{print $2}')
  TIMES=$(printf '%s\n' "$normalized" | awk -F= '$1=="times"{print $2}')
  INTERVAL=$(printf '%s\n' "$normalized" | awk -F= '$1=="interval_minutes"{print $2}')
  AUTOSTART=$(printf '%s\n' "$normalized" | awk -F= '$1=="autostart"{print $2}')
  DELAY=$(printf '%s\n' "$normalized" | awk -F= '$1=="delay_seconds"{print $2}')
}
uptime_seconds() { local up rest; read -r up rest < /proc/uptime; printf '%s\n' "${up%%.*}"; }
boot_id() { cat /proc/sys/kernel/random/boot_id; }
local_date() { if [ -x /system/bin/date ]; then /system/bin/date "$@"; else date "$@"; fi; }
android_only() {
  [ -x /system/bin/getprop ] && [ "$(id -u)" = 0 ] || { echo 'Android mit Root erforderlich.' >&2; return 1; }
}
worker_running() {
  local pid cmd
  pid=$(cat "$DATA/daemon.pid" 2>/dev/null)
  case "$pid" in ''|*[!0-9]*) return 1;; esac
  [ -r "/proc/$pid/cmdline" ] || return 1
  cmd=$(tr '\000' ' ' < "/proc/$pid/cmdline")
  case "$cmd" in *"$MODDIR/daemon.sh"*) kill -0 "$pid" 2>/dev/null;; *) return 1;; esac
}
start_worker() {
  [ "${WATTPIT_TEST:-}" = 1 ] && [ ! -x /system/bin/getprop ] && return 0
  android_only || return 1
  [ ! -f "$MODDIR/disable" ] && [ ! -f "$MODDIR/remove" ] || return 0
  worker_running && return 0
  nohup /system/bin/sh "$MODDIR/daemon.sh" >/dev/null 2>&1 < /dev/null &
}
event() {
  local temp="$DATA/log.$$"
  { local_date '+%d.%m.%Y %H:%M:%S'; printf '%s\n' "$1"; printf '\n'; head -n 57 "$DATA/log" 2>/dev/null; } > "$temp"
  mv "$temp" "$DATA/log"
}
state_put() {
  printf '%s\n' "$2" > "$DATA/$1.$$" && mv "$DATA/$1.$$" "$DATA/$1"
}
save_lock() {
  local owner pid cmd attempt
  for attempt in 1 2; do
    if mkdir "$DATA/save.lock" 2>/dev/null; then
      printf '%s\n' "$$" > "$DATA/save.lock/owner"
      return 0
    fi
    sleep 1
    pid=$(cat "$DATA/save.lock/owner" 2>/dev/null)
    cmd=''
    case "$pid" in ''|*[!0-9]*) ;; *) [ ! -r "/proc/$pid/cmdline" ] || cmd=$(tr '\000' ' ' < "/proc/$pid/cmdline");; esac
    case "$cmd" in *"$MODDIR/control.sh"*) return 1;; esac
    rm -f "$DATA/save.lock/owner"
    rmdir "$DATA/save.lock" 2>/dev/null
  done
  return 1
}
read_number() {
  local n
  n=$(cat "$DATA/$1" 2>/dev/null)
  case "$n" in ''|*[!0-9]*) printf '0';; *) printf '%s' "$n";; esac
}
# Pure decision function: callers supply a local minute and elapsed uptime.
# A wall-clock slot is attempted once per date; missed slots are never replayed.
due() {
  local now="$1" stamp="$2" first_minute="$3" ready="$4" anchor="$5" fired="$6"
  [ "$ENABLED" = 1 ] || return 1
  [ "$now" -ge "$((ready + 120))" ] || return 1
  if [ "$MODE" = interval ]; then
    [ "$now" -ge "$((anchor + INTERVAL * 60))" ] || return 1
    printf 'interval:%s\n' "$anchor"
  else
    [ "$stamp" != "$first_minute" ] || return 1
    [ "$stamp" != "$fired" ] || return 1
    local hhmm
    hhmm=$(printf '%s' "$stamp" | cut -c9-10):$(printf '%s' "$stamp" | cut -c11-12)
    case ",$TIMES," in *",$hhmm,"*) printf 'time:%s\n' "$stamp";; *) return 1;; esac
  fi
}
launch_due() {
  [ "$4" = 1 ] && [ "$5" = 0 ] && [ "$1" -ge "$(($2 + $3))" ] && { [ "$6" = 0 ] || [ "$1" -ge "$(($6 + 30))" ]; }
}
open_app() {
  android_only || return 1
  local result code
  result=$(/system/bin/am start --user current -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -n de.wattpit.app/.MainActivity 2>&1); code=$?
  case "$result" in *'Error:'*|*'Exception'*) code=1;; esac
  if [ "$code" != 0 ]; then
    event 'Watt’n’Pit konnte nicht geöffnet werden. Installation und Berechtigungen prüfen.'
    return 1
  fi
  event 'Watt’n’Pit geöffnet.'
}
