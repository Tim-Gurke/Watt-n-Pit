BEGIN { FS="="; allowed["version"]=1; allowed["enabled"]=1; allowed["mode"]=1; allowed["times"]=1; allowed["interval_minutes"]=1; allowed["autostart"]=1; allowed["delay_seconds"]=1 }
function fail(message) { if(!bad) print message > "/dev/stderr"; bad=1 }
function integer(s,max) { return s ~ /^(0|[1-9][0-9]*)$/ && length(s)<=10 && s+0<=max }
{
  if(NF!=2 || !($1 in allowed) || seen[$1]++) {fail("Ungültige oder doppelte Einstellung."); next}
  v[$1]=$2
}
END {
  for(key in allowed) if(!seen[key]) fail("Eine Einstellung fehlt.")
  if(v["version"]!="1") fail("Unbekannte Einstellungs-Version.")
  if(v["enabled"]!~/^[01]$/ || v["autostart"]!~/^[01]$/) fail("Ein/Aus-Wert ist ungültig.")
  if(v["mode"]!="times" && v["mode"]!="interval") fail("Unbekannter Zeitplan.")
  if(!integer(v["interval_minutes"],525600) || v["interval_minutes"]+0<2) fail("Das Intervall muss zwischen 2 und 525600 Minuten liegen.")
  if(!integer(v["delay_seconds"],31536000)) fail("Die Startverzögerung ist ungültig (0 bis 31536000 Sekunden).")
  if(v["times"]!="") {
    count=split(v["times"],times,",")
    if(count>1440) fail("Zu viele Uhrzeiten.")
    for(i=1;i<=count;i++) {
      if(times[i]!~/^[0-2][0-9]:[0-5][0-9]$/ || substr(times[i],1,2)+0>23 || duplicate[times[i]]++) fail("Uhrzeiten müssen gültig und eindeutig sein.")
    }
  }
  if(v["enabled"]=="1" && v["mode"]=="times" && v["times"]=="") fail("Mindestens eine Uhrzeit eintragen oder Neustarts ausschalten.")
  if(v["enabled"]=="1" && v["mode"]=="interval" && v["autostart"]=="1" && v["interval_minutes"]*60<=v["delay_seconds"]+30) fail("Das Neustartintervall muss länger als die Startverzögerung plus 30 Sekunden sein.")
  if(bad) exit 1
  print "version=1\nenabled=" v["enabled"] "\nmode=" v["mode"] "\ntimes=" v["times"] "\ninterval_minutes=" v["interval_minutes"] "\nautostart=" v["autostart"] "\ndelay_seconds=" v["delay_seconds"]
}
