#!/system/bin/sh
[ "$BOOTMODE" = true ] || abort "Bitte in der Magisk-App installieren."
[ "$API" -ge 26 ] || abort "Android 8 oder neuer erforderlich."
set_perm_recursive "$MODPATH" 0 0 0755 0644
for f in service.sh action.sh uninstall.sh common.sh control.sh daemon.sh; do
  set_perm "$MODPATH/$f" 0 0 0755
done
ui_print "Watt’n’Pit · Zentralen-Planer"
ui_print "Neustarts bleiben zunächst AUS."
ui_print "Neuinstallation: Autostart EIN, Startverzögerung 60 Sekunden."
ui_print "Bestehende Einstellungen bleiben bei Updates erhalten."
ui_print "Oberfläche: KsuWebUI installieren, Root erlauben, Modul öffnen."
