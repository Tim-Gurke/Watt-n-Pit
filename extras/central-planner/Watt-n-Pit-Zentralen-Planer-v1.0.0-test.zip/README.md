# Watt’n’Pit · Zentralen-Planer 1.0.0-test

Magisk-Modul für eine Android-Zentrale: frei wählbare Handy-Neustarts und ein separat einstellbarer, verzögerter Start von Watt’n’Pit. Das Handy wird normal neu gestartet; es wird keine Ausschaltpause eingerichtet.

## Installation auf dem G5

1. Die fertige Modul-ZIP unverändert auf das G5 herunterladen. Nicht entpacken.
2. In Magisk unter **Module → Aus Speicher installieren** die ZIP wählen. Anschließend das G5 einmal neu starten.
3. Den kleinen **KsuWebUI**-Betrachter installieren. Offizielle Projekt-Veröffentlichung: <https://github.com/KOWX712/KsuWebUIStandalone/releases/tag/v1.0>. Dort `KsuWebUI-1.0-48-release.apk` herunterladen. Der Betrachter unterstützt Android 8 oder neuer.
4. KsuWebUI öffnen, Root-Zugriff in Magisk erlauben und **Watt’n’Pit · Zentralen-Planer** auswählen. Alternativ öffnet die **Aktion**-Schaltfläche des Magisk-Moduls die Oberfläche. Falls eine ältere Magisk-Version diese Schaltfläche noch nicht hat, direkt KsuWebUI verwenden.
5. Zeiten und App-Startverzögerung einstellen und **Einstellungen speichern** drücken. Die Neustart-Automatik erst aktivieren, wenn der gewünschte Plan eingetragen ist.

Bei einer Neuinstallation sind **geplante Neustarts aus**, **App-Autostart ein** und die **App-Startverzögerung 60 Sekunden**. Daher kann Watt’n’Pit schon nach dem ersten Testneustart automatisch erscheinen. Vorhandene Einstellungen werden bei Modul-Updates beibehalten.

## Bedienung

- **Feste Uhrzeiten:** Beliebig viele unterschiedliche tägliche Uhrzeiten hinzufügen oder entfernen. Es gibt bis zu 1440 verschiedene Minuten eines Tages.
- **Gleichmäßig verteilen:** Beispielsweise `100` eintragen, um 100 Termine über 24 Stunden zu verteilen. `0` leert die Liste und schaltet geplante Neustarts aus. Änderungen anschließend speichern.
- **Intervall:** Regelmäßig nach X Minuten Laufzeit neu starten. Das Intervall zählt ab Android-Bereitschaft, nach einem ausgeführten Neustart wieder ab der nächsten Android-Bereitschaft. Eine Änderung der Neustart-Einstellungen beginnt das Intervall neu. Änderungen allein an der App-Startverzögerung verschieben es nicht.
- **Appstart verzögern:** Ganze Sekunden oder Minuten eingeben, etwa `5 Minuten` oder `300 Sekunden`. `0` bedeutet ohne zusätzliche Wartezeit, sobald Android seinen Start abgeschlossen hat. Die Einstellung ist unabhängig von der Neustart-Automatik.
- **Status:** Zeigt den gespeicherten Plan, den Zustand der Zeitsteuerung und den nächsten geplanten Neustart. Ungespeicherte Änderungen werden ausdrücklich gekennzeichnet.
- **Watt’n’Pit öffnen:** Öffnet die App sofort, um den Startbefehl zu prüfen. Dieser Knopf führt keinen Handy-Neustart aus.

Die Aufzeichnung in Watt’n’Pit sollte zuvor eingeschaltet gewesen sein. Version 1.6.13 nimmt sie beim erneuten Öffnen anhand der bestehenden Einstellung wieder auf. Bluetooth, WLAN und die bestehenden App-Berechtigungen müssen verfügbar bleiben. Die vorhandene Konfiguration als Zentrale bleibt erhalten.

## Zeitverhalten

Die Anzeige verwendet die lokale Android-Uhrzeit. Der Dienst prüft ungefähr alle zehn Sekunden. Android-Tiefschlaf kann eine Ausführung verzögern; für eine minutengenaue Weckfunktion aus jedem Schlafzustand ist dieses Modul nicht ausgelegt. Der Zentraleservice von Watt’n’Pit 1.6.13 hält die CPU im aktiven Zentralbetrieb bereits mit einem eigenen WakeLock verfügbar. Das Modul fügt keinen weiteren dauerhaften WakeLock hinzu.

In den ersten zwei Minuten nach Android-Bereitschaft wird kein geplanter Neustart angefordert. Termine während des Hochfahrens, während das Handy aus war oder in der Minute der Aktivierung einer geänderten Planung werden nicht nachgeholt. Eine ausgeführte Uhrzeit wird mit Datum vor dem Neustart gespeichert; auch ein Rückstellen der Uhr darf diesen Termin nicht nochmals auslösen. Bei Intervallen muss genug Zeit für den ausgewählten Appstart verbleiben.

Die App-Startverzögerung wird ab Android-Bereitschaft gemessen, nicht ab dem Druck auf den Einschaltknopf. Ein bereits ausgeführter automatischer Appstart wird in demselben Systemstart nicht wiederholt. Wenn Android einen Appstart ablehnt, wird frühestens nach 30 Sekunden erneut versucht.

## Ausschalten und Entfernen

**Handy automatisch neu starten** aus und speichern: keine geplanten Neustarts; der getrennte App-Autostart bleibt nach seiner eigenen Einstellung aktiv. Zum vollständigen Abschalten beide Schalter aus und speichern oder das Modul in Magisk deaktivieren. Bei Deaktivierung beendet sich der Dienst innerhalb von etwa zehn Sekunden. Entfernen des Moduls beendet den Dienst und entfernt seine eigenen Einstellungen. Watt’n’Pit-Daten werden nicht verändert.

## Prüfung und Grenzen

Geprüft wurden auf dem Entwicklungsrechner die tatsächlichen Shell-Einstellungen, Eingabeprüfung, persistente Speicherung, alte Formularstände, unterbrochene Speichervorgänge, Zeitentscheidungen, Appstart-Fristen und die grafische Bedienung über eine simulierte KsuWebUI-Bridge zum echten Shell-Backend. Die Anzeige wurde bei 320, 360 und 720 Pixel Breite, in Hell/Dunkel und mit 100/150 % Schriftgröße geprüft. Details stehen unter `tests/` und in `VERIFICATION.json`.

Ein echter Magisk-Installationsvorgang, ein Android-Neustart und die Reaktion des physischen G5 konnten am Entwicklungsrechner nicht geprüft werden. Das erste Paket ist deshalb eine Testversion. Es enthält keine Verbindung zu einem Cloud-Dienst und keinen Webserver. Die Oberfläche läuft lokal im KsuWebUI-Betrachter; der Zeitdienst benötigt den Betrachter nicht geöffnet.

## Quellcode und Lizenz

Der vollständige Quellcode ist in dieser ZIP enthalten. Die Dateien `common.sh`, `control.sh`, `daemon.sh`, `service.sh`, `action.sh`, `uninstall.sh`, `validate.awk` und `webroot/` enthalten die Implementierung. `tests/` enthält die Host-Prüfungen.

GPL-3.0; Lizenztext siehe `LICENSE`. Der originale Magisk-Installationsstarter unter `META-INF/com/google/android/update-binary` wurde unverändert aus dem Magisk-Projekt übernommen:

<https://github.com/topjohnwu/Magisk/blob/33bfff7ce750c27f157ddb4580e36bf842d6d95b/scripts/module_installer.sh>

Magisk-Moduldokumentation: <https://topjohnwu.github.io/Magisk/guides.html>

KsuWebUI-Bridge und Startschnittstelle wurden gegen die Quellen der oben verlinkten Veröffentlichung `v1.0` geprüft:

<https://github.com/KOWX712/KsuWebUIStandalone/blob/v1.0/app/src/main/java/io/github/a13e300/ksuwebui/WebUIActivity.kt>

<https://github.com/KOWX712/KsuWebUIStandalone/blob/v1.0/app/src/main/java/io/github/a13e300/ksuwebui/WebViewInterface.kt>
