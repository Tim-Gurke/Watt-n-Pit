(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.Planner=api;})(typeof globalThis==='object'?globalThis:this,function(){
  'use strict';
  const timePattern=/^(?:[01]\d|2[0-3]):[0-5]\d$/;
  function times(value){if(!value)return [];const out=value.split(',');if(out.some(x=>!timePattern.test(x))||new Set(out).size!==out.length)throw Error('Uhrzeiten müssen gültig und eindeutig sein.');return out.sort();}
  function distribute(n){if(!Number.isInteger(n)||n<0||n>1440)throw Error('Bitte eine ganze Zahl zwischen 0 und 1440 eingeben.');return Array.from({length:n},(_,i)=>{const m=Math.floor(i*1440/n);return String(Math.floor(m/60)).padStart(2,'0')+':'+String(m%60).padStart(2,'0');});}
  function validate(c){
    if(![0,1].includes(c.enabled)||![0,1].includes(c.autostart)||!['times','interval'].includes(c.mode))throw Error('Ungültige Auswahl.');
    times(c.times);
    if(!Number.isInteger(c.interval_minutes)||c.interval_minutes<2||c.interval_minutes>525600)throw Error('Das Intervall muss zwischen 2 und 525600 Minuten liegen.');
    if(!Number.isInteger(c.delay_seconds)||c.delay_seconds<0||c.delay_seconds>31536000)throw Error('Bitte eine gültige Startverzögerung eingeben.');
    if(c.enabled&&c.mode==='times'&&!c.times)throw Error('Mindestens eine Uhrzeit eintragen oder Neustarts ausschalten.');
    if(c.enabled&&c.mode==='interval'&&c.autostart&&c.interval_minutes*60<=c.delay_seconds+30)throw Error('Das Neustartintervall muss länger als die Startverzögerung plus 30 Sekunden sein.');
    return c;
  }
  function encode(c){validate(c);return ['version=1','enabled='+c.enabled,'mode='+c.mode,'times='+times(c.times).join(','),'interval_minutes='+c.interval_minutes,'autostart='+c.autostart,'delay_seconds='+c.delay_seconds].join('\n')+'\n';}
  function next(c,state,now=new Date()){
    if(!c.enabled)return null;
    const minimum=state.ready>0?new Date(+now+Math.max(0,state.ready+120-state.uptime)*1000):now;
    if(c.mode==='interval'){
      if(!state.ready||!state.anchor)return null;
      return new Date(+now+Math.max(0,Math.max(state.anchor+c.interval_minutes*60,state.ready+120)-state.uptime)*1000);
    }
    const list=times(c.times);
    for(let day=0;day<3;day++){
      for(const t of list){const [h,m]=t.split(':').map(Number),d=new Date(now);d.setDate(now.getDate()+day);d.setHours(h,m,0,0);if(+d>+now&&+d>=+minimum)return d;}
    }
    return null;
  }
  return {times,distribute,validate,encode,next};
});
