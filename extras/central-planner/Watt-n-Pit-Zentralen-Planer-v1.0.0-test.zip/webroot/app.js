(function(){
  'use strict';
  const $=id=>document.getElementById(id),P=window.Planner;
  let current=null,entries=[],dirty=false,saving=false,sequence=0,refreshSequence=0,currentUnit=1,moduleDir='/data/adb/modules/wattpit_reboot';
  function message(text,error=false){$('message').textContent=text;$('message').classList.toggle('error',error);$('message').hidden=!text;}
  function quote(s){return "'"+s.replace(/'/g,"'\\''")+"'";}
  function exec(action,args=[]){return new Promise((resolve,reject)=>{
    if(!window.ksu||typeof window.ksu.exec!=='function')return reject(Error('Bitte diese Oberfläche in KsuWebUI öffnen und dort Root erlauben.'));
    const key='plannerReply'+(++sequence),timer=setTimeout(()=>{delete window[key];reject(Error('Keine Antwort. Root-Freigabe prüfen und erneut versuchen.'));},15000);
    window[key]=(code,out,err)=>{clearTimeout(timer);delete window[key];if(Number(code)!==0)return reject(Error(err||out||'Die Aktion ist fehlgeschlagen.'));try{resolve(JSON.parse(out));}catch(_){reject(Error('Die Antwort des Moduls konnte nicht gelesen werden.'));}};
    const cmd='/system/bin/sh '+quote(moduleDir+'/control.sh')+' '+[action,...args].map(quote).join(' ');
    try{window.ksu.exec(cmd,'{}',key);}catch(e){clearTimeout(timer);delete window[key];reject(e);}
  });}
  function changed(){dirty=true;$('unsaved').hidden=false;message('');visibility();}
  function visibility(){
    $('fixedFields').hidden=$('mode').value!=='times';$('intervalFields').hidden=$('mode').value!=='interval';$('delayFields').hidden=!$('autostart').checked;
  }
  function renderTimes(){
    $('timeList').replaceChildren();
    for(const t of entries){const row=document.createElement('div'),time=document.createElement('time'),button=document.createElement('button');row.className='time-item';time.textContent=t;button.type='button';button.className='remove';button.textContent='×';button.setAttribute('aria-label',t+' entfernen');button.onclick=()=>{entries=entries.filter(x=>x!==t);renderTimes();changed();};row.append(time,button);$('timeList').append(row);}
    $('timeCount').textContent=entries.length+' pro Tag';
  }
  function fill(c){
    $('enabled').checked=!!c.enabled;$('mode').value=c.mode;entries=P.times(c.times);renderTimes();$('interval').value=c.interval_minutes;$('autostart').checked=!!c.autostart;
    const minutes=c.delay_seconds>0&&c.delay_seconds%60===0;$('delayUnit').value=minutes?'60':'1';$('delay').value=minutes?c.delay_seconds/60:c.delay_seconds;
    currentUnit=Number($('delayUnit').value);$('delay').step=currentUnit===60?'any':'1';
    dirty=false;$('unsaved').hidden=true;visibility();
  }
  function values(){if($('delay').value===''||$('interval').value==='')throw Error('Bitte die Zahlenfelder ausfüllen.');return P.validate({enabled:+$('enabled').checked,mode:$('mode').value,times:entries.join(','),interval_minutes:Number($('interval').value),autostart:+$('autostart').checked,delay_seconds:Number($('delay').value)*Number($('delayUnit').value)});}
  function human(n){return n%60===0?n/60+' min':n+' s';}
  function status(){
    if(!current)return;
    const c=current.config,s=current.state;
    $('workerStatus').textContent=s.disabled?'Modul in Magisk deaktiviert':s.running?'Zeitsteuerung läuft':'Zeitsteuerung startet beim nächsten Handy-Neustart';$('statusDot').classList.toggle('running',s.running&&!s.disabled);
    const next=P.next(c,s);
    $('nextReboot').textContent=!c.enabled?'Ausgeschaltet':s.disabled?'Modul deaktiviert':!s.running?'Nach dem nächsten Systemstart':next?next.toLocaleString('de-DE',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'Warte auf Android';
    $('launchStatus').textContent=!c.autostart?'Ausgeschaltet':s.launched?'Für diesen Systemstart ausgeführt':s.ready?Math.max(0,s.ready+c.delay_seconds-s.uptime)>0?'In etwa '+human(Math.ceil(Math.max(0,s.ready+c.delay_seconds-s.uptime)/10)*10):'Appstart steht an':human(c.delay_seconds)+' nach Android-Bereitschaft';
    try{$('log').textContent=decodeURIComponent(Array.from(atob(s.logBase64||''),x=>'%'+x.charCodeAt(0).toString(16).padStart(2,'0')).join(''))||'Noch keine Vorgänge.';}catch(_){$('log').textContent='Protokoll konnte nicht gelesen werden.';}
  }
  async function reload(force=false){
    if(saving)return;
    const refresh=++refreshSequence;
    try{const data=await exec('read');if(refresh!==refreshSequence||saving)return;current=data;if(force||!dirty)fill(data.config);status();$('fields').disabled=false;if(force)message('Gespeicherte Einstellungen geladen.');}
    catch(e){message(e.message,true);}
  }
  $('settings').addEventListener('input',changed);$('settings').addEventListener('change',changed);
  $('addTime').onclick=()=>{
    const t=$('newTime').value;
    if(!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(t)){message('Bitte eine gültige Uhrzeit wählen.',true);return;}
    if(entries.includes(t)){message('Diese Uhrzeit steht bereits im Plan.',true);return;}
    entries=[...entries,t].sort();renderTimes();changed();message('');
  };
  $('distribute').onclick=()=>{try{entries=P.distribute(Number($('count').value));if(!entries.length)$('enabled').checked=false;renderTimes();changed();message('Uhrzeiten verteilt. Zum Übernehmen speichern.');}catch(e){message(e.message,true);}};
  $('delayUnit').onchange=()=>{const next=Number($('delayUnit').value),previous=currentUnit;const seconds=Number($('delay').value)*previous;$('delay').value=seconds/next;$('delay').step=next===60?'any':'1';currentUnit=next;changed();};
  $('settings').onsubmit=async e=>{
    e.preventDefault();if(saving||!current)return;
    try{const config=values(),payload=btoa(P.encode(config));saving=true;refreshSequence++;$('fields').disabled=true;const data=await exec('save',[payload,current.revision]);current=data;fill(data.config);currentUnit=Number($('delayUnit').value);status();message('Gespeichert. Die Zeitsteuerung übernimmt Änderungen innerhalb von etwa zehn Sekunden.');}
    catch(e){message(e.message,true);}finally{saving=false;$('fields').disabled=false;}
  };
  $('reload').onclick=()=>reload(true);
  $('openApp').onclick=async()=>{try{await exec('open');message('Watt’n’Pit wurde geöffnet.');}catch(e){message(e.message,true);}};
  try{if(window.ksu&&window.ksu.moduleInfo){const info=JSON.parse(window.ksu.moduleInfo());if(info.moduleDir==='/data/adb/modules/wattpit_reboot')moduleDir=info.moduleDir;}}catch(_){}
  reload().then(()=>{currentUnit=Number($('delayUnit').value);});
  setInterval(()=>reload(),10000);
})();
