#!/system/bin/sh
MODDIR=${0%/*}
if pm path io.github.a13e300.ksuwebui >/dev/null 2>&1; then
  am start --user current -n io.github.a13e300.ksuwebui/.WebUIActivity --es id "${MODDIR##*/}" --es name 'Watt’n’Pit · Zentralen-Planer'
else
  echo 'Für die Einstellungen bitte KsuWebUI installieren und Root erlauben.'
  echo 'Offizieller Download: https://github.com/KOWX712/KsuWebUIStandalone/releases/tag/v1.0'
  am start -a android.intent.action.VIEW -d https://github.com/KOWX712/KsuWebUIStandalone/releases/tag/v1.0
fi
